## NoSuggReels

Clean up your Facebook feed with ease! Remove all 'Suggested for you' and 'Reels' posts from you feed using this lightweight browser extension.