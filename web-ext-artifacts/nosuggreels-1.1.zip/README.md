## NoSuggReels

Clean up your Facebook feed with ease! Remove all 'Suggested for you', 'Reels' and 'Sponsored' posts from you feed using this lightweight browser extension.